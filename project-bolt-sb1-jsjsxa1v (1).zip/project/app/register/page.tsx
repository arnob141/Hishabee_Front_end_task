'use client';

import { RegistrationForm } from '@/components/auth/registration-form';

export default function RegisterPage() {
  return <RegistrationForm />;
}